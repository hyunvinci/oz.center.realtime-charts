A Pen created at CodePen.io. You can find this one at https://codepen.io/rozklad/pen/OOMGza.

 Chart.js line chart with transparent points and custom labels.