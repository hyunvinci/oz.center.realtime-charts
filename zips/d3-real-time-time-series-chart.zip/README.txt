A Pen created at CodePen.io. You can find this one at https://codepen.io/browles/pen/mPMBjw.

 A "real-time" chart displaying faux data via d3.js. 

